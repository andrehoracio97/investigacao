var classuhd_1_1usrp_1_1dboard__iface =
[
    [ "atr_reg_t", "classuhd_1_1usrp_1_1dboard__iface.html#a7967c68b6067a0a4414c009a4b247c2e", null ],
    [ "special_props_t", "classuhd_1_1usrp_1_1dboard__iface.html#a3b04bc6de633c96bc2854a74bb47cf72", null ],
    [ "sptr", "classuhd_1_1usrp_1_1dboard__iface.html#a59c880b1ce74b17f9aec67426d37a4c8", null ],
    [ "aux_adc_t", "classuhd_1_1usrp_1_1dboard__iface.html#a2a7475c974d1e454311ab88f92b41fa7", [
      [ "AUX_ADC_A", "classuhd_1_1usrp_1_1dboard__iface.html#a2a7475c974d1e454311ab88f92b41fa7ae68da619c198fe8ad31e3e9f8fdb8492", null ],
      [ "AUX_ADC_B", "classuhd_1_1usrp_1_1dboard__iface.html#a2a7475c974d1e454311ab88f92b41fa7afc3a24356e776efa159d95469142096e", null ]
    ] ],
    [ "aux_dac_t", "classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720", [
      [ "AUX_DAC_A", "classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720a4f21321dffddc75eb339669280d09304", null ],
      [ "AUX_DAC_B", "classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720a5fe9e65851b0bd66268b5c8b5d879b12", null ],
      [ "AUX_DAC_C", "classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720aa4f963494141c4eada1899623cc054cd", null ],
      [ "AUX_DAC_D", "classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720a0ccc4235e51dfe3b3617a570842f3753", null ]
    ] ],
    [ "unit_t", "classuhd_1_1usrp_1_1dboard__iface.html#a90ca5745ab1db9145cd66cafc62f00d1", [
      [ "UNIT_RX", "classuhd_1_1usrp_1_1dboard__iface.html#a90ca5745ab1db9145cd66cafc62f00d1a030fafad883127e265514bacabec97f8", null ],
      [ "UNIT_TX", "classuhd_1_1usrp_1_1dboard__iface.html#a90ca5745ab1db9145cd66cafc62f00d1acc95c631c9e3e29487c332b8da8a52ec", null ],
      [ "UNIT_BOTH", "classuhd_1_1usrp_1_1dboard__iface.html#a90ca5745ab1db9145cd66cafc62f00d1a0de2945e35d75acb673f97f487189c6c", null ]
    ] ],
    [ "~dboard_iface", "classuhd_1_1usrp_1_1dboard__iface.html#a4f6caf21850e5912d4b2154ee0249b75", null ],
    [ "get_atr_reg", "classuhd_1_1usrp_1_1dboard__iface.html#a08fa445e614c7e698083c052c6c9b52b", null ],
    [ "get_clock_rate", "classuhd_1_1usrp_1_1dboard__iface.html#ae87f3b9dc3f6af7e08c9f5e297e6ce5c", null ],
    [ "get_clock_rates", "classuhd_1_1usrp_1_1dboard__iface.html#a88039aa0d8fa5e028e578e9f06f1d4e1", null ],
    [ "get_codec_rate", "classuhd_1_1usrp_1_1dboard__iface.html#aa2dcb230a055a3f14bcc990573549720", null ],
    [ "get_command_time", "classuhd_1_1usrp_1_1dboard__iface.html#a675548621d0b565277c2da2b0822712b", null ],
    [ "get_gpio_ddr", "classuhd_1_1usrp_1_1dboard__iface.html#a0e64846baf6032d460fd2bcba3e66f17", null ],
    [ "get_gpio_out", "classuhd_1_1usrp_1_1dboard__iface.html#a78248471016ae021bc11c4012ece4181", null ],
    [ "get_pin_ctrl", "classuhd_1_1usrp_1_1dboard__iface.html#aa8585dc27e252ade72705d2d50483949", null ],
    [ "get_special_props", "classuhd_1_1usrp_1_1dboard__iface.html#a4debd94e68f8cda5dca96af43c665b59", null ],
    [ "has_set_fe_connection", "classuhd_1_1usrp_1_1dboard__iface.html#aa6e8cc93ab3dc932e746ea5d45553049", null ],
    [ "read_aux_adc", "classuhd_1_1usrp_1_1dboard__iface.html#af447663ae52a783468717560c6da814d", null ],
    [ "read_gpio", "classuhd_1_1usrp_1_1dboard__iface.html#adcbf21cce8e4f0d79e1b51941a578fde", null ],
    [ "read_write_spi", "classuhd_1_1usrp_1_1dboard__iface.html#aabc9cfc8dbbd746862fa455f6dfe4f46", null ],
    [ "set_atr_reg", "classuhd_1_1usrp_1_1dboard__iface.html#a5259b95f57938d05635014d1636b7d14", null ],
    [ "set_clock_enabled", "classuhd_1_1usrp_1_1dboard__iface.html#af93d409325b75c681cf272168fe7b988", null ],
    [ "set_clock_rate", "classuhd_1_1usrp_1_1dboard__iface.html#a2f346356eca7ce63343b636b66d57b30", null ],
    [ "set_command_time", "classuhd_1_1usrp_1_1dboard__iface.html#a628a08b5c56d8784e1ce55352db7a4d3", null ],
    [ "set_fe_connection", "classuhd_1_1usrp_1_1dboard__iface.html#a94f656592de3102e07ad544f522a1066", null ],
    [ "set_gpio_ddr", "classuhd_1_1usrp_1_1dboard__iface.html#a1047135352cf324d4f20584ea3b5da06", null ],
    [ "set_gpio_out", "classuhd_1_1usrp_1_1dboard__iface.html#a905463df329c5c08e078f3ad0af1b0f3", null ],
    [ "set_pin_ctrl", "classuhd_1_1usrp_1_1dboard__iface.html#a8c5d12c95f1db19edcb5623d44a2abf9", null ],
    [ "sleep", "classuhd_1_1usrp_1_1dboard__iface.html#acde76ff167a9cfdc3e97e86e63bdbf06", null ],
    [ "write_aux_dac", "classuhd_1_1usrp_1_1dboard__iface.html#a6f5769841c9a1d8e96b69e50e4377f0e", null ],
    [ "write_spi", "classuhd_1_1usrp_1_1dboard__iface.html#adbae1863373e6f2e8ebc9f8d099e9aea", null ]
];