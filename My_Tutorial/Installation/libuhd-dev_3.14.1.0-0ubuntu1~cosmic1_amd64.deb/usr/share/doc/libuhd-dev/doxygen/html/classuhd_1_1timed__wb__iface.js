var classuhd_1_1timed__wb__iface =
[
    [ "sptr", "classuhd_1_1timed__wb__iface.html#a308541650d29266beebf9aa09bbbb411", null ],
    [ "get_time", "classuhd_1_1timed__wb__iface.html#ad2af934ff25a83367d92f48da3dcadb0", null ],
    [ "set_time", "classuhd_1_1timed__wb__iface.html#a35bef39fd40c563d6578d7cbeab7d89f", null ]
];