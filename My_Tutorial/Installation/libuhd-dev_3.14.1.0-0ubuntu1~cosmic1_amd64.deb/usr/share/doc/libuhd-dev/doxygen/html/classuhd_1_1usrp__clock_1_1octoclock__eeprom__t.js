var classuhd_1_1usrp__clock_1_1octoclock__eeprom__t =
[
    [ "octoclock_eeprom_t", "classuhd_1_1usrp__clock_1_1octoclock__eeprom__t.html#a0c08f8602d24307630bb7cdbdae1c4d3", null ],
    [ "octoclock_eeprom_t", "classuhd_1_1usrp__clock_1_1octoclock__eeprom__t.html#aca38a34950f0bf396bdf494f374c9f1b", null ],
    [ "commit", "classuhd_1_1usrp__clock_1_1octoclock__eeprom__t.html#a0fff54d32a6cca88baf5a4f022db4ae8", null ]
];