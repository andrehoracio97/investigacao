var classuhd_1_1transport_1_1zero__copy__recv__offload =
[
    [ "sptr", "classuhd_1_1transport_1_1zero__copy__recv__offload.html#a33ec22ce35eb7e67995d80fe5227decf", null ]
];