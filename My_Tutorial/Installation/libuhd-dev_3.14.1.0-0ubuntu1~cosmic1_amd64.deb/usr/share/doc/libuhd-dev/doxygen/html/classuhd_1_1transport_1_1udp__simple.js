var classuhd_1_1transport_1_1udp__simple =
[
    [ "sptr", "classuhd_1_1transport_1_1udp__simple.html#a9fa6fd0ef26d04e3db96adbd6079755f", null ],
    [ "~udp_simple", "classuhd_1_1transport_1_1udp__simple.html#ac21df3f37e547e29d2289542e241706f", null ],
    [ "get_recv_addr", "classuhd_1_1transport_1_1udp__simple.html#af27556dc0ed12a9817bc34eb013dc61c", null ],
    [ "get_send_addr", "classuhd_1_1transport_1_1udp__simple.html#ac83cc0a3b8420972c3c4a3c77b9c529e", null ],
    [ "recv", "classuhd_1_1transport_1_1udp__simple.html#ac3962ef3810504c93b640b19a5e076f7", null ],
    [ "send", "classuhd_1_1transport_1_1udp__simple.html#aca3d6fef6f4031db66451c4a888fa897", null ]
];