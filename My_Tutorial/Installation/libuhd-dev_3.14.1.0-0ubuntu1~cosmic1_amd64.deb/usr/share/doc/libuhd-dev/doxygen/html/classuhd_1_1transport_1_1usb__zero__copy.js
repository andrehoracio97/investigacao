var classuhd_1_1transport_1_1usb__zero__copy =
[
    [ "sptr", "classuhd_1_1transport_1_1usb__zero__copy.html#a7ec604f4d45523122f86505a60402e41", null ],
    [ "~usb_zero_copy", "classuhd_1_1transport_1_1usb__zero__copy.html#aa294a9cc01ce5d87d6e05a953731016b", null ]
];