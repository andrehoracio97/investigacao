var classuhd_1_1i2c__iface =
[
    [ "sptr", "classuhd_1_1i2c__iface.html#a65140bfd1527b10f13cb1e5a37f3a3e9", null ],
    [ "~i2c_iface", "classuhd_1_1i2c__iface.html#a9c84f3853f743914395e7036f940d6f0", null ],
    [ "eeprom16", "classuhd_1_1i2c__iface.html#abb67ce0ae3254672299cc6b1333e7643", null ],
    [ "read_eeprom", "classuhd_1_1i2c__iface.html#a7f6e8fafa01167c6764d7648c6fb16fb", null ],
    [ "read_i2c", "classuhd_1_1i2c__iface.html#a25420938d103ff4ccb56fa7e09fa17e2", null ],
    [ "write_eeprom", "classuhd_1_1i2c__iface.html#adc0ae5cac1bdb5b3b2dfb68759c2ed12", null ],
    [ "write_i2c", "classuhd_1_1i2c__iface.html#a9d6303d9a90ff7f7a0a023fa6d0fd52f", null ]
];