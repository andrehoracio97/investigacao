var classuhd_1_1transport_1_1muxed__zero__copy__if =
[
    [ "sptr", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#a50408a50c03dbd4cea342daafbcd5331", null ],
    [ "stream_classifier_fn", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#aeeb6ede08ae4dc7306a6102bb5c17638", null ],
    [ "~muxed_zero_copy_if", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#a8ce4001367d2f5adbf36354b5626eee1", null ],
    [ "get_num_dropped_frames", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#aaa208dbc45adda71a34725c63ba3cddf", null ],
    [ "make_stream", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#a97de6c7d26fb1944b6c6e3490a0e00a7", null ],
    [ "remove_stream", "classuhd_1_1transport_1_1muxed__zero__copy__if.html#a8e74fc62af77e7727adfc4fa7d5a5a9a", null ]
];