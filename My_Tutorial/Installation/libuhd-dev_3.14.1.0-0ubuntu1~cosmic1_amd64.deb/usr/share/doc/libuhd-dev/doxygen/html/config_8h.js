var config_8h =
[
    [ "UHD_ALIGNED", "config_8h.html#a91d58ac7c1d79816eb260a32ba36affd", null ],
    [ "UHD_API", "config_8h.html#adc68e1c030efb88af856decedf19aedf", null ],
    [ "UHD_DEPRECATED", "config_8h.html#a009518b78c453470e2856bebf2746f37", null ],
    [ "UHD_EXPORT", "config_8h.html#a312283ab505e1210f48db5e10f99e5e4", null ],
    [ "UHD_IMPORT", "config_8h.html#a3933ce975896a086c0aabb8cee9dd2f0", null ],
    [ "UHD_INLINE", "config_8h.html#a8b9b549161081d54c2161046649a0323", null ],
    [ "UHD_UNUSED", "config_8h.html#ada94fcec1883b1e6a65535881f6da0ed", null ]
];