var classuhd_1_1transport_1_1managed__recv__buffer =
[
    [ "sptr", "classuhd_1_1transport_1_1managed__recv__buffer.html#a00e07a3493c36ce8b54a609268ee7896", null ]
];