var classuhd_1_1task =
[
    [ "sptr", "classuhd_1_1task.html#ac6390689088ad51df5e4e43f83162911", null ],
    [ "task_fcn_type", "classuhd_1_1task.html#a9662b5f3077187e12961fcb4625f1f8c", null ]
];