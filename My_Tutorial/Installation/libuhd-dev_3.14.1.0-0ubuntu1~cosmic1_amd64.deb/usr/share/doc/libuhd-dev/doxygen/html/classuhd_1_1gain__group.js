var classuhd_1_1gain__group =
[
    [ "sptr", "classuhd_1_1gain__group.html#ad078123fa276b71972ea7f7dc42dd9a2", null ],
    [ "~gain_group", "classuhd_1_1gain__group.html#af455fc55ac58bbe51eca2a7351615563", null ],
    [ "get_names", "classuhd_1_1gain__group.html#a4c6f3b811ec08fb5cae6b82aba07a06d", null ],
    [ "get_range", "classuhd_1_1gain__group.html#a4cf983c072a4d5e6164866c6da6a9eb5", null ],
    [ "get_value", "classuhd_1_1gain__group.html#a8a052a161418873a3a16e423b0917678", null ],
    [ "register_fcns", "classuhd_1_1gain__group.html#a3104dfb1b4e869c12358ad22184940ba", null ],
    [ "set_value", "classuhd_1_1gain__group.html#a5df641ad73319fac4098948bff534238", null ]
];