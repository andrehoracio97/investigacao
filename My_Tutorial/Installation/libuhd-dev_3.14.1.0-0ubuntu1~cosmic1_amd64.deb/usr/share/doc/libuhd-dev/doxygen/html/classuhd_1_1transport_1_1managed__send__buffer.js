var classuhd_1_1transport_1_1managed__send__buffer =
[
    [ "sptr", "classuhd_1_1transport_1_1managed__send__buffer.html#a6bb69c3e7d8f762a065dd66f6f8b3e41", null ]
];