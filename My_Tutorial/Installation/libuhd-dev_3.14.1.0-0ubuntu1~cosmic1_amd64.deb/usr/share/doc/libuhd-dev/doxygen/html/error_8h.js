var error_8h =
[
    [ "uhd_error", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2b", [
      [ "UHD_ERROR_NONE", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba6e16630248c317cdf8fde4711e62e7eb", null ],
      [ "UHD_ERROR_INVALID_DEVICE", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2bae6b1b7c2e037cb0839e589a2435a4be9", null ],
      [ "UHD_ERROR_INDEX", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba5fb1c17736c2511370e3322093fc5793", null ],
      [ "UHD_ERROR_KEY", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2baa3cb3fdb7e9291339d559d0191eb81a1", null ],
      [ "UHD_ERROR_NOT_IMPLEMENTED", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba81f6862e5d3aa4634699fa5c57ad9fbe", null ],
      [ "UHD_ERROR_USB", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2baf1d544f219a717ea0478ff8d27d26dcc", null ],
      [ "UHD_ERROR_IO", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba7e4d8ea6763a6cb37fae42c023b1d2d6", null ],
      [ "UHD_ERROR_OS", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba2de2f6589005aea6e2c8b5b7a20e24ad", null ],
      [ "UHD_ERROR_ASSERTION", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba59829d0fc28459df62b18c88122a3d70", null ],
      [ "UHD_ERROR_LOOKUP", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba860cc1c57d308675913dabbfd197a8c2", null ],
      [ "UHD_ERROR_TYPE", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2bac8f1900d29b0ab05d1416eb0aa3d3d6c", null ],
      [ "UHD_ERROR_VALUE", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba6fe44348a26903a69bff309d3bc146cb", null ],
      [ "UHD_ERROR_RUNTIME", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2babf5e1454ec71fe6fd57d8aac9753ec29", null ],
      [ "UHD_ERROR_ENVIRONMENT", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2baf368fb8234728f21471225c17babf693", null ],
      [ "UHD_ERROR_SYSTEM", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2baf3ee0cc48dc3d602d57f27ba59711784", null ],
      [ "UHD_ERROR_EXCEPT", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba987e337142e80be5cbdc1bbe6774f06c", null ],
      [ "UHD_ERROR_BOOSTEXCEPT", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba08c60a1888a6c4e74a89fb09b20c76b4", null ],
      [ "UHD_ERROR_STDEXCEPT", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2ba5ac37536660a54f800a430d1a8f76f34", null ],
      [ "UHD_ERROR_UNKNOWN", "error_8h.html#a7fbc3f872dadd2c73cd656b2e5acdd2baec3e42279af6c4cc4c94cb2ee48359de", null ]
    ] ],
    [ "uhd_get_last_error", "error_8h.html#a1117d0fcab17ff7969969b0d64081716", null ]
];