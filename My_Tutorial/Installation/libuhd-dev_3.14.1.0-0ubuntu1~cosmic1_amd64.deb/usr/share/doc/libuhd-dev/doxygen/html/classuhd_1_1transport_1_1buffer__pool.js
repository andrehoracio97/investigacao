var classuhd_1_1transport_1_1buffer__pool =
[
    [ "ptr_type", "classuhd_1_1transport_1_1buffer__pool.html#ad729c883e930eaba93daf846f0a50166", null ],
    [ "sptr", "classuhd_1_1transport_1_1buffer__pool.html#a9e13ea162804e19e927b9f354d41b0a7", null ],
    [ "~buffer_pool", "classuhd_1_1transport_1_1buffer__pool.html#a2d97f93fa65a31298e99397fce7898de", null ],
    [ "at", "classuhd_1_1transport_1_1buffer__pool.html#abe13583d3dc22534efff90f6880f958e", null ],
    [ "size", "classuhd_1_1transport_1_1buffer__pool.html#a71b3c330703ef30d1a1db80f0101698a", null ]
];