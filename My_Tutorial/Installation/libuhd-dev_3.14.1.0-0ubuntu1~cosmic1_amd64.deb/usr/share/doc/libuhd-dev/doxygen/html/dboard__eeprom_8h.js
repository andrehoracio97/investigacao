var dboard__eeprom_8h =
[
    [ "uhd_dboard_eeprom_handle", "dboard__eeprom_8h.html#aa37096bcf0fff9da8d04dfb3fa7adcf4", null ],
    [ "uhd_dboard_eeprom_free", "dboard__eeprom_8h.html#a44a389a376a6cc56087520f4f252e625", null ],
    [ "uhd_dboard_eeprom_get_id", "dboard__eeprom_8h.html#a9f53d812599713e8b034bb8680b8ad04", null ],
    [ "uhd_dboard_eeprom_get_revision", "dboard__eeprom_8h.html#a2a0303506086e5e091e2d479b1e85c9d", null ],
    [ "uhd_dboard_eeprom_get_serial", "dboard__eeprom_8h.html#a3094bf521a5bbd002d110bac9088e3c7", null ],
    [ "uhd_dboard_eeprom_last_error", "dboard__eeprom_8h.html#aa8e9d3789b5e2d5aee9562e2cd7be6a5", null ],
    [ "uhd_dboard_eeprom_make", "dboard__eeprom_8h.html#a87d08f787112cd0f38d5fa4dfd418724", null ],
    [ "uhd_dboard_eeprom_set_id", "dboard__eeprom_8h.html#a011c93703c4db41f1b6eade00aa25a4d", null ],
    [ "uhd_dboard_eeprom_set_revision", "dboard__eeprom_8h.html#a7d16766ca9899f03e0d6a1ec072a78b5", null ],
    [ "uhd_dboard_eeprom_set_serial", "dboard__eeprom_8h.html#adc9c0aa3f16e365d6b64a841bed2600f", null ]
];