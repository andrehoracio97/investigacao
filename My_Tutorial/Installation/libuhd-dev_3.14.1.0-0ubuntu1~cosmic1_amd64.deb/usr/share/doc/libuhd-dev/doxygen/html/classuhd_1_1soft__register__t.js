var classuhd_1_1soft__register__t =
[
    [ "sptr", "classuhd_1_1soft__register__t.html#a27edf07cbe6fb9ab8cb3d6b77a8116a2", null ],
    [ "soft_register_t", "classuhd_1_1soft__register__t.html#a9faf5a03cb4c2922257f7352ededa499", null ],
    [ "soft_register_t", "classuhd_1_1soft__register__t.html#a183d25d18d91af393c3ce54d405516f0", null ],
    [ "flush", "classuhd_1_1soft__register__t.html#aa5b8b74639052ef94f653881d7899383", null ],
    [ "get", "classuhd_1_1soft__register__t.html#a7640b77ce19487bcea73db063bb956d5", null ],
    [ "get_bitwidth", "classuhd_1_1soft__register__t.html#a931b4a00077fb95bf462166a6afb6647", null ],
    [ "initialize", "classuhd_1_1soft__register__t.html#a27e986af0e7fd89b877e90c564e7954d", null ],
    [ "is_readable", "classuhd_1_1soft__register__t.html#aacd8829233e80c90483d29e7af22cc74", null ],
    [ "is_writable", "classuhd_1_1soft__register__t.html#abb20563f84b2f381e1d462a31a2f7aaf", null ],
    [ "read", "classuhd_1_1soft__register__t.html#a651edd10e01c62d4b7e07c746798dd38", null ],
    [ "refresh", "classuhd_1_1soft__register__t.html#a4de586272e3e811ae9dba95e534fba9e", null ],
    [ "set", "classuhd_1_1soft__register__t.html#a505353527c1aa55f25189b9477d48945", null ],
    [ "write", "classuhd_1_1soft__register__t.html#a29f6bb8eac7a7990e5fd930743e2ff8b", null ]
];