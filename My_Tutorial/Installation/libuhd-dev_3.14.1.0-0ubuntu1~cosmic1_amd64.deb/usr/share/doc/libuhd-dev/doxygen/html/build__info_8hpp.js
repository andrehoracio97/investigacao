var build__info_8hpp =
[
    [ "boost_version", "build__info_8hpp.html#a1de103fb5a62999ae63a08667545926e", null ],
    [ "build_date", "build__info_8hpp.html#a62036dcb76957bcc3321d305e65cb636", null ],
    [ "c_compiler", "build__info_8hpp.html#a4d6f22aa707a16e8f22ba8d3b3b2e2f4", null ],
    [ "c_flags", "build__info_8hpp.html#ac1539f5890b237d78f56dea1f90e815c", null ],
    [ "cxx_compiler", "build__info_8hpp.html#a92776007b27d731eaf626728168999cf", null ],
    [ "cxx_flags", "build__info_8hpp.html#a48459dd48aff4730dfaa3269120776e9", null ],
    [ "enabled_components", "build__info_8hpp.html#aa77a3e960b26c3984a2b1c1bfd1e199b", null ],
    [ "install_prefix", "build__info_8hpp.html#a0aca1a52ef376c0edd76505cb90f8fff", null ],
    [ "libusb_version", "build__info_8hpp.html#afec427394610ee88b52493d702cddeb9", null ]
];