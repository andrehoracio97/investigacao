var classuhd_1_1spi__iface =
[
    [ "sptr", "classuhd_1_1spi__iface.html#a5c449b4d49d7d0bb616d6d840eda403f", null ],
    [ "~spi_iface", "classuhd_1_1spi__iface.html#a5bf64a423056fdbf68b4f2450fc23527", null ],
    [ "read_spi", "classuhd_1_1spi__iface.html#a6360fb3737608bbdfce4e5e1834b7145", null ],
    [ "transact_spi", "classuhd_1_1spi__iface.html#a60fa28de8512f988a2c2c3ad254f2787", null ],
    [ "write_spi", "classuhd_1_1spi__iface.html#ab563011e54f466a9747da3451f6b1b27", null ]
];