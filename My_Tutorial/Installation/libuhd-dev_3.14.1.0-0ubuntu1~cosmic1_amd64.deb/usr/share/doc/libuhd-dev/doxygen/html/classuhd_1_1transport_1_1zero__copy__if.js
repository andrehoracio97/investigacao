var classuhd_1_1transport_1_1zero__copy__if =
[
    [ "sptr", "classuhd_1_1transport_1_1zero__copy__if.html#aee1d3b676905a547aede35b85438e613", null ],
    [ "~zero_copy_if", "classuhd_1_1transport_1_1zero__copy__if.html#a90e0e317f33f7c54d17407801d364ede", null ],
    [ "get_num_recv_frames", "classuhd_1_1transport_1_1zero__copy__if.html#ac534cc62f48bc595c86c94bedab2a710", null ],
    [ "get_num_send_frames", "classuhd_1_1transport_1_1zero__copy__if.html#a4515f92660540b757f1861d5a1657a4b", null ],
    [ "get_recv_buff", "classuhd_1_1transport_1_1zero__copy__if.html#a616c3bbf1f7e7f750eed9546057e2e09", null ],
    [ "get_recv_frame_size", "classuhd_1_1transport_1_1zero__copy__if.html#a867e3b83108e352e9cf904c0148a100b", null ],
    [ "get_send_buff", "classuhd_1_1transport_1_1zero__copy__if.html#a1fc3168c5f9e7d23487e4ae83e3b597c", null ],
    [ "get_send_frame_size", "classuhd_1_1transport_1_1zero__copy__if.html#a8f3dcc2576760b9ebb944b1b23ee5b2d", null ]
];