var classuhd_1_1image__loader =
[
    [ "image_loader_args_t", "structuhd_1_1image__loader_1_1image__loader__args__t.html", "structuhd_1_1image__loader_1_1image__loader__args__t" ],
    [ "loader_fcn_t", "classuhd_1_1image__loader.html#abc0bd0e2894c2b7672eb73db4530ab66", null ]
];