var endianness_8hpp =
[
    [ "endianness_t", "endianness_8hpp.html#af746201b81b1ae9ff3c559a1aa733478", [
      [ "ENDIANNESS_BIG", "endianness_8hpp.html#af746201b81b1ae9ff3c559a1aa733478ade5e0754edb0b34a18ba4407fc5c407b", null ],
      [ "ENDIANNESS_LITTLE", "endianness_8hpp.html#af746201b81b1ae9ff3c559a1aa733478a82c8d2bbe3a8fc8a22b0fdc0ee0e5a67", null ]
    ] ]
];