var classuhd_1_1transport_1_1managed__buffer =
[
    [ "sptr", "classuhd_1_1transport_1_1managed__buffer.html#acf117d1cdfc052362f701f63ec1390af", null ],
    [ "managed_buffer", "classuhd_1_1transport_1_1managed__buffer.html#a35e4a3cbfd1d6704d8497a205ff6c9f3", null ],
    [ "~managed_buffer", "classuhd_1_1transport_1_1managed__buffer.html#aa03dbc092f0d8dbe41f4a0cab54ecf51", null ],
    [ "cast", "classuhd_1_1transport_1_1managed__buffer.html#ae164ac01ad5c00318cc6596d1043f7a5", null ],
    [ "commit", "classuhd_1_1transport_1_1managed__buffer.html#a18a1d5f3e8996bb75a3ba4bf27ebdbff", null ],
    [ "make", "classuhd_1_1transport_1_1managed__buffer.html#af93160f0440e18652142b56a0dd0dba6", null ],
    [ "ref_count", "classuhd_1_1transport_1_1managed__buffer.html#a0add4d0b654ed789a8513a14625657fb", null ],
    [ "release", "classuhd_1_1transport_1_1managed__buffer.html#afc7064023c7dbe6a03e31128fa270715", null ],
    [ "size", "classuhd_1_1transport_1_1managed__buffer.html#ab42c45dab1c2935b28fe8c6715f105cb", null ],
    [ "_buffer", "classuhd_1_1transport_1_1managed__buffer.html#ad25617124b960dff45a6916acc7df42f", null ],
    [ "_length", "classuhd_1_1transport_1_1managed__buffer.html#a486a6c5dce84878c8431b73a553d28fa", null ],
    [ "_ref_count", "classuhd_1_1transport_1_1managed__buffer.html#a2a2404a5e656c1c23f930e1eb51cf583", null ]
];