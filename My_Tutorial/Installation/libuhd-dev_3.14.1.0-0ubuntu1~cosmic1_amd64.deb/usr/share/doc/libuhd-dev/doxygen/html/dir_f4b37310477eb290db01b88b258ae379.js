var dir_f4b37310477eb290db01b88b258ae379 =
[
    [ "algorithm.hpp", "algorithm_8hpp.html", "algorithm_8hpp" ],
    [ "assert_has.hpp", "assert__has_8hpp.html", "assert__has_8hpp" ],
    [ "assert_has.ipp", "assert__has_8ipp.html", "assert__has_8ipp" ],
    [ "byteswap.hpp", "byteswap_8hpp.html", "byteswap_8hpp" ],
    [ "byteswap.ipp", "byteswap_8ipp.html", "byteswap_8ipp" ],
    [ "cast.hpp", "cast_8hpp.html", "cast_8hpp" ],
    [ "csv.hpp", "csv_8hpp.html", "csv_8hpp" ],
    [ "dirty_tracked.hpp", "dirty__tracked_8hpp.html", [
      [ "dirty_tracked", "classuhd_1_1dirty__tracked.html", "classuhd_1_1dirty__tracked" ]
    ] ],
    [ "fp_compare_delta.ipp", "fp__compare__delta_8ipp.html", "fp__compare__delta_8ipp" ],
    [ "fp_compare_epsilon.ipp", "fp__compare__epsilon_8ipp.html", "fp__compare__epsilon_8ipp" ],
    [ "gain_group.hpp", "gain__group_8hpp.html", [
      [ "gain_fcns_t", "structuhd_1_1gain__fcns__t.html", "structuhd_1_1gain__fcns__t" ],
      [ "gain_group", "classuhd_1_1gain__group.html", "classuhd_1_1gain__group" ]
    ] ],
    [ "log.h", "log_8h.html", "log_8h" ],
    [ "log.hpp", "log_8hpp.html", "log_8hpp" ],
    [ "log_add.hpp", "log__add_8hpp.html", "log__add_8hpp" ],
    [ "math.hpp", "math_8hpp.html", "math_8hpp" ],
    [ "msg_task.hpp", "msg__task_8hpp.html", [
      [ "msg_task", "classuhd_1_1msg__task.html", "classuhd_1_1msg__task" ]
    ] ],
    [ "paths.hpp", "paths_8hpp.html", "paths_8hpp" ],
    [ "pimpl.hpp", "pimpl_8hpp.html", "pimpl_8hpp" ],
    [ "platform.hpp", "platform_8hpp.html", "platform_8hpp" ],
    [ "safe_call.hpp", "safe__call_8hpp.html", "safe__call_8hpp" ],
    [ "safe_main.hpp", "safe__main_8hpp.html", "safe__main_8hpp" ],
    [ "soft_register.hpp", "soft__register_8hpp.html", "soft__register_8hpp" ],
    [ "static.hpp", "static_8hpp.html", "static_8hpp" ],
    [ "tasks.hpp", "tasks_8hpp.html", [
      [ "task", "classuhd_1_1task.html", "classuhd_1_1task" ]
    ] ],
    [ "thread.hpp", "thread_8hpp.html", "thread_8hpp" ],
    [ "thread_priority.h", "thread__priority_8h.html", "thread__priority_8h" ],
    [ "thread_priority.hpp", "thread__priority_8hpp.html", null ]
];