// The OTW type API has been deprecated in favor of the streamer interface
#include <uhd/deprecated.hpp>
